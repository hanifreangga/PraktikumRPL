<!DOCTYPE html>
<html>
<head>
	<title><?= $judul; ?></title>
	
	<!-- BOOTSTRAP 4 -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?= base_url('assets/') ?>css/bootstrap.min.css">

	<!-- FONT AWESOME -->
	<link href="<?= base_url('assets/') ?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

	<!-- SBADMIN -->
	<link href="<?= base_url('assets/') ?>css/sb-admin.css" rel="stylesheet">

</head>
<body>