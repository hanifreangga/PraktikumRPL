<div class="footer">
    <p>SiJaka @ 2021</p>
</div>
<!-- Bootstrap core JavaScript-->
<script src="<?= base_url("assets/") ?>vendor/jquery/jquery.min.js"></script>
<script src="<?= base_url("assets/") ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="<?= base_url("assets/") ?>vendor/jquery-easing/jquery.easing.min.js"></script>


<script src="<?= base_url("assets/") ?>css/chatbot.css"></script>
</body>

</html>